docker run -it -d --name ubuntu1 -p 22:22  docker-ubuntu
